import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";

export default function About() {
  const skills = [
    { icon: "fab fa-discord", name: "Discord.js & Bot Development", color: "text-indigo-500" },
    { icon: "fab fa-node-js", name: "Node.js & Express", color: "text-green-500" },
    { icon: "fas fa-shield-alt", name: "Antinuke & Security Systems", color: "text-red-500" },
    { icon: "fas fa-microphone", name: "RTC & Voice Features", color: "text-purple-500" },
  ];

  return (
    <section id="about" className="py-20 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="animate-on-scroll">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              About <span className="gradient-text">Me</span>
            </h2>

            <p className="text-lg text-muted-foreground mb-6">
              I'm a passionate Full Stack Developer and the creator of Cryptora, a Discord multipurpose bot with advanced antinuke and RTC capabilities.
              I specialize in Discord bot development, Node.js, and creating powerful automation tools for Discord communities.
            </p>

            <p className="text-lg text-muted-foreground mb-8">
              Cryptora is designed to provide comprehensive server protection, moderation features, and real-time communication enhancements.
              When I'm not developing bot features, you'll find me exploring new Discord API capabilities and enhancing server security systems.
            </p>

            <div className="mb-8">
              <h3 className="text-xl font-semibold mb-4">Core Skills</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {skills.map((skill, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <i className={`${skill.icon} ${skill.color} text-xl`}></i>
                    <span className="text-foreground">{skill.name}</span>
                  </div>
                ))}
              </div>
            </div>

            <Button
              asChild
              className="bg-primary hover:bg-primary/90 text-primary-foreground px-6 py-3 rounded-lg font-medium transition-all duration-200 hover:scale-105 shadow-lg"
            >
              <a href="/resume.pdf" download>
                <Download className="w-4 h-4 mr-2" />
                Download Resume
              </a>
            </Button>
          </div>

          <div className="animate-on-scroll">
            <img
              src="https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000"
              alt="Futuristic anime aesthetic artwork"
              className="rounded-2xl shadow-2xl w-full h-auto object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
